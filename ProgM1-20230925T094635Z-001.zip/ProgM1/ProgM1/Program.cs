﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgM1
{
    internal class Program
    {
        /*static void Main(string[] args)
        {
            Console.Write("Inserisci la targa (L4-L3-L2-L1-C3-C2-C1): ");
            string targa = Console.ReadLine();

            int risultato = ConvertiTarga(targa);

            Console.WriteLine($"Il risultato della conversione è: {risultato}");
            Console.ReadLine();
        }

        static int ConvertiTarga(string targa)
        {
            int risultato = 0;

            // Definiamo l'alfabeto per calcolare N
            string alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            // Invertiamo la stringa della targa per facilitare i calcoli
            char[] targaArray = targa.ToCharArray();
            Array.Reverse(targaArray);
            string targaInvertita = new string(targaArray);

            for (int i = 0; i < targaInvertita.Length; i++)
            {
                char carattere = targaInvertita[i];

                if (char.IsLetter(carattere))
                {
                    // Troviamo la posizione della lettera nell'alfabeto (N)
                    int posizione = alfabeto.IndexOf(char.ToUpper(carattere)) + 1;
                    risultato += posizione * (int)Math.Pow(10, i + 3);
                }
                else if (char.IsDigit(carattere))
                {
                    int cifra = int.Parse(carattere.ToString());
                    risultato += cifra * (int)Math.Pow(10, i);
                }
            }

            return risultato;
        }*/

        static void Main()
        {
            Console.Write("Inserisci la targa (L4-L3-L2-L1-C3-C2-C1): ");
            string targa = Console.ReadLine();

            long risultato = ConvertiTarga(targa);

            Console.WriteLine($"Il risultato della conversione è: {risultato}");
            Console.ReadLine();
        }

        static int ConvertiTarga(string targa)
        {
            int risultato = 0;

            // Definiamo l'alfabeto per calcolare N
            string alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            for (int i = 0; i < targa.Length; i++)
            {
                char carattere = targa[i];

                int posizione = alfabeto.IndexOf(char.ToUpper(carattere)) + 1;
                risultato += posizione * (int)Math.Pow(10, i + 3);
            }

            return risultato;

        }

        /*static void Main()
        {
            Console.Write("Inserisci la targa (L4-L3-L2-L1-C3-C2-C1): ");
            string targa = Console.ReadLine();

            long risultato = ConvertiTarga(targa);

            Console.WriteLine($"Il risultato della conversione è: {risultato}");
            Console.ReadLine();
        }

        static long ConvertiTarga(string targa)
        {
            long risultato = 0;

            for (int i = targa.Length - 1; i >= 0; i--)
            {
                char carattere = targa[i];

                if (char.IsLetter(carattere))
                {
                    int posizioneAlfabeto = char.ToUpper(carattere) - 'A';
                    risultato += posizioneAlfabeto * (long)Math.Pow(26, targa.Length - i - 1) * 1000;
                }
                else if (char.IsDigit(carattere))
                {
                    int cifra = int.Parse(carattere.ToString());
                    risultato += cifra * (long)Math.Pow(10, targa.Length - i - 1);
                }
            }

            return risultato;
        }*/
    }
}
